export class Constant {
    /*Development Mode */
     public static API_URL: string = "http://localhost:8080/";
}