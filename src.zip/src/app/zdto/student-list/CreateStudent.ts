export class CreateStudent {
      firstName : string;
      lastName : string;
      address: string;
  }