export class StudentInfoResponse {
  id: number;
    firstName : string;
    lastName : string;
    address: string;
  }